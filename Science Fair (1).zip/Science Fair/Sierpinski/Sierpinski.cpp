#include <GL/glut.h>  // GLUT, include glu.h and gl.h
//#include <dos.h> //for delay
#include <list>



struct Point
{
   double x;
   double y;
}



class Triangle {
   
   Point vertex1;
   Point vertex2;
   Point vertex3;
   float color[3];

   Triangle(Point v1, Point v2, Point v3)
   {
      vertex1 = v1;
      vertex2 = v2;
      vertex3 = v3;

   }


   void setColor(float r, float g, float b)
   {
      color[0] = r;
      color[1] = g;
      color[2] = b
   }


   void draw()
   {

      glBegin(GL_TRIANGLES);          // Each set of 3 vertices form a triangle
         glColor3f(color[0], color[1], color[2]); // Blue
         glVertex2f(vertex1.x, vertex1.y);
         glVertex2f(vertex2.x, vertex2.y);
         glVertex2f(vertex3.x, vertex3.y);
      glEnd();

   }
};

List<Triangle> triangles;

int n = 1;


void initGL() {
   // Set "clearing" or background color
   glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Black and opaque

}



Point findMidpoint(Point p1, Point p2)
{
   Point mid;
   mid.x = (p1.x + p2.x)/2.0;
   mid.y = (p1.y + p2.y)/2.0;
   
  return mid;

}



void make3Triangles(Triangle t, List<triangle>& trls)
{
   
   Point mid1 = findMidpoint(t.vertex1, t.vertex2);
   Point mid2 = findMidpoint(t.vertex2, t.vertex3);
   Point mid3 = findMidpoint(t.vertex1, t.vertex3);
   
   
   Triangle trl1;
   trl1.vertex1 = t.vertex1;
   trl1.vertex2 = mid1;
   trl1.vertex3 = mid3;
   trl1.setColor(0.0f, 0.0f, 1.0f); 
   trls.push_back(trl1);

   trl1.vertex1 = mid1;
   trl1.vertex2 = t.vertex2;
   trl1.vertex3 = mid2;
   trl1.setColor(0.0f, 0.0f, 1.0f); 
   trls.push_back(trl1);

   trl1.vertex1 = mid3;
   trl1.vertex2 = mid2;
   trl1.vertex3 = t.vertex3;
   trl1.setColor(0.0f, 0.0f, 1.0f); 
   trls.push_back(trl1);

   trls.remove(t);


}


void display()
{
   glClear(GL_COLOR_BUFFER_BIT);
   for(auto trl = triangles.begin(); trl != triangles.end(); trl++)
   {
      trl.draw();
   }
   glFlush();

   
}

void initTriangle()
{
   Point p1, p2, p3;
   p1.x = 100;
   p1.y = 400;
   p2.x = 400;
   p2.y = 400;
   p3.x = 250;
   p3.y = 400 - 300*sin(60*(M_PI/180.0));
   Triangle trl = new Triangle(p1, p2, p3);
   trl.setColor(0.0f, 0.0f, 1.0f);
   triangles.push_back(trl);

   display();
   //delay(250);



}

void Sierpinski()
{
   initTriangle();
   for(int i = 1; i < n-1;i++)
   {
      for(auto trl = triangles.begin(); trl != triangles.end(); trl++)
      {
         make3Triangles(trl, triangles);
         if(triangles.size() >= Math.pow(3, i))
         {
            break;
         }

      }

      display();
      //delay(250);


   }

}


int main(int argc, char** argv)
{
  
   n = 5;//number of iterations, initialized at the top

   glutInit(&argc, argv);          // Initialize GLUT
   glutCreateWindow("Sierpinski");  // Create window with the given title
   glutInitWindowSize(500, 500);   // Set the window's initial width & height
   glutInitWindowPosition(50, 50); // Position the window's initial top-left corner
   glutDisplayFunc(Sierpinski);       // Register callback handler for window re-paint event
   initGL();                       // Our own OpenGL initialization
   glutMainLoop();                 // Enter the event-processing loop
   return 0;
}