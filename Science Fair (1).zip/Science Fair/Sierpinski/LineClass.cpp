//Class Line

#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include <stdio.h>
#include <string.h>
//#include "Eigen/Dense"
#include <math.h>
//#include <ComplexClass.cpp>

#include <list>
#include <SDL2/SDL.h> // or #include <SDL.h>

//using namespace Eigen;
using namespace std;
//#define _USE_MATH_DEFINES;



class Line
{

private:

	//variables:
	double angle, x ,y, length;
	


public:

	Line(double X, double Y, double ang, int l)//constructors and methods
	{
		x = X;
		y = Y;
		angle = ang;
		length = l;
	}

	Line()
	{
		x = y = 0;
		angle = 180;
		length = 100;
	}

	//getter and setter methods
	double getX()
	{
		return x;
	}

	double getY()
	{
		return y;
	}

	double getAngle()
	{
		return angle;
	}

	double getLength()
	{
		return length;
	}

	double getEndX()
	{
		return x + cos(angle*(M_PI/180)) *length;
	}

	double getEndY()
	{
		return y + sin(angle*(M_PI/180)) *length;
	}

	//add setter methods?


	void draw()
	{
		SDL_SetRenderDrawColor(renderer, 100, 255, 100, 255); // Setting the color of the line
		SDL_RenderDrawLine(renderer, x, y, getX2(), getY2()); // Drawing the line
		SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255); // Resetting the color
	}



}