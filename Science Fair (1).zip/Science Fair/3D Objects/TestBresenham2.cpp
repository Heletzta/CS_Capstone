/*




void First_Octant_Bresenham(int x0, int y0, int x1, int y1)
{
	int e = 0;
	int y = y0;
	int x = x0;
	int dx = x1-x0;
	int dy = y1-y0;
	
	for(x <= x1; x++)//this would only work if x is less than x1
	{
		//fill in the point
		
		if(2(e+dy) < dx)
		{
			e += dy;
		}
		else
		{
			e = e + dy - dx;
			y += 1;
		}
		
	}

		
	
}*/

/*vector<Triple> pointFill;

void fill(int x,int y)
{
	for(int i = 0; i < height; i++)//check if this is the right order.
	{
		for(int j = 0; < width; j++)
		{
			
		}
	}
	pointFill.push_back()
}
*/
/*Double coordinate;
vector<Double> coordinates;

void Bresenham(int x1, int y1, int x2, int y2)
{
	int X = x1;
	int Y = y1;
	int dx = abs(x2-x1);
	int dy = abs(y2-y1);
	int Sx = x2-x1;
	int Sy = y2-y1;
	bool interchange;

	if(dy > dx)
	{
		int T = dx;
		dx = dy;
		dy = T;
		interchange = true;
	}
	else
	{
		interchange = false;
	}
	
	int E = 2*dy - dx;
	int A = 2*dy;
	int B = 2*dy -2*dx;

	coordinate.x = X;
	coordinate.y = Y;
	coordinates.push_back(coordinate);

	for(int i = 1; i < dx; i++)
	{
		if(E < 0)
		{
			if(interchange)
			{
				Y = Y + Sy;
			}
			else
			{
				X = X + Sx;
				E = E + A;
			}
		}
		else
		{
			Y = Y + Sy;
			X = Y + Sx;
			E = E + B;
		}
	}
	coordinate.x = X;
	coordinate.y = Y;
	coordinates.push_back(coordinate);

}*/
#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include <stdio.h>
#include <string.h>
#include "Eigen/Dense"
#include <math.h>
#include <cstring>
#include <map> 

using namespace Eigen;
using namespace std;

struct Double //makes a type that can store 3 values: x, y, and z coordinates
{
    float x;
    float y;
};

int height = 500;
int width = 500;
//Double coordinate;
//vector<Double> coordinates;
int Sign(int b)
{
	if(b < 0)
	{
		return -1;
	}
	else if(b == 0)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}


map<int, int> coordinates;
void Bresenham(int x1, int y1, int x2, int y2)
{
	int Xs = x1;
	int Ys = y1;
	int Xe = x2;
	int Ye = y2;
	/*if (x1>x2){
		Xs=x2;
		Ys=y2;
		Xe=x1;
		Ye=y1;
	}*/

	int X = Xs;
	int Y = Ys;
	int dx = abs(Xe-Xs);
	int dy = abs(Ye-Ys);
	int Sx = Sign(Xe-Xs);
	int Sy = Sign(Ye-Ys);
	bool interchange;

	if(dy > dx)
	{
		int T = dx;
		dx = dy;
		dy = T;
		interchange = true;
	}
	else
	{
		interchange = false;
	}
	
	int E = 2*dy - dx;
	int A = 2*dy;
	int B = 2*dy -2*dx;

	cout << "Sx="<<Sx<<"; Sy="<<Sy<<"; interchange="<<interchange<<"; E="<<E<<"; A="<<A<<"; B="<<B<<";\n";

	coordinates[X] = Y;
	cout << "draw first point : ("<< X << ", " << Y << ")"<<endl;

	for(int i = 1; i <= dx; i++)
	{
		if(E < 0)
		{
			if(interchange)
			{
				Y = Y + Sy;
			}
			else
			{
				X = X + Sx;
				E = E + A;
			}
		}
		else
		{
			Y = Y + Sy;
			X = X + Sx;
			E = E + B;
		}
		coordinates[X] = Y;
		cout << "E="<<E<<"; draw point : ("<< X << ", " << Y << ")"<<endl;
	}
	
	
	/*for(int k = 0; k < coordinates.size(); k++)
	{
		if(coordinate.x != coordinates[k].x || coordinate.y != coordinates[k].y)
		{
			coordinates.push_back(coordinate);
		}
	}*/

}




int main(int argc,  char **argv)// (number of arguments, array of arguments) First value
//of the array is always the name of the document
{
	/// add in for loops so that it does it for each file given
	/*if (argc <= 1)
	{
		//printf("Error: must input at least one object file path.");
		return 0;
	}

	//projectionMatrix(1, 10, -0.5, 0.5, 0.5, -0.5);
	//finalNDC();
	
	
	for(int k = 1; k < argc; k++)
	{
		cout << k << " " << argv[k] << endl;
		//beginningRead(argv[k]);
		
		Bresenham(0, 0, 5, 5);

	}	
*/

	//Bresenham(50, 30, 90, 70);

	Bresenham(90, 70, 30, 10);
	ofstream outputFile;
	outputFile.open("HELLO.ppm");

	outputFile << "P3 " << endl << width << " " << height << endl << " 255" << endl;
	for(int y = 0; y < height; y++)
	{
		for(int x = 0; x < width; x++)
		{
			
			if(coordinates.find(x) != coordinates.end() && coordinates.at(x) == y)
			{
				//cout << "Drawing coordinate x: " << x << " and y: " << y << endl;
				outputFile << "255 255 255" << endl;
			}
			else
			{
				outputFile << "20 20 20" << endl;
			}
			//outputFile << "255 255 255" << endl;
			/*for(int k = 0; k < coordinates.size(); k++)
			{
				if(coordinates[k].x == x && coordinates[k].y == y)
				{
					outputFile << "255 255 255" << endl;
				}
				else
				{
					outputFile << "0 0 0" << endl;
				}
			}*/
		}
	}

	outputFile.close();

}
