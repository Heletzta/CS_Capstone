/*




void First_Octant_Bresenham(int x0, int y0, int x1, int y1)
{
	int e = 0;
	int y = y0;
	int x = x0;
	int dx = x1-x0;
	int dy = y1-y0;
	
	for(x <= x1; x++)//this would only work if x is less than x1
	{
		//fill in the point
		
		if(2(e+dy) < dx)
		{
			e += dy;
		}
		else
		{
			e = e + dy - dx;
			y += 1;
		}
		
	}

		
	
}*/

/*vector<Triple> pointFill;

void fill(int x,int y)
{
	for(int i = 0; i < height; i++)//check if this is the right order.
	{
		for(int j = 0; < width; j++)
		{
			
		}
	}
	pointFill.push_back()
}
*/
/*Double coordinate;
vector<Double> coordinates;

void Bresenham(int x1, int y1, int x2, int y2)
{
	int X = x1;
	int Y = y1;
	int dx = abs(x2-x1);
	int dy = abs(y2-y1);
	int Sx = x2-x1;
	int Sy = y2-y1;
	bool interchange;

	if(dy > dx)
	{
		int T = dx;
		dx = dy;
		dy = T;
		interchange = true;
	}
	else
	{
		interchange = false;
	}
	
	int E = 2*dy - dx;
	int A = 2*dy;
	int B = 2*dy -2*dx;

	coordinate.x = X;
	coordinate.y = Y;
	coordinates.push_back(coordinate);

	for(int i = 1; i < dx; i++)
	{
		if(E < 0)
		{
			if(interchange)
			{
				Y = Y + Sy;
			}
			else
			{
				X = X + Sx;
				E = E + A;
			}
		}
		else
		{
			Y = Y + Sy;
			X = Y + Sx;
			E = E + B;
		}
	}
	coordinate.x = X;
	coordinate.y = Y;
	coordinates.push_back(coordinate);

}*/
#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include <stdio.h>
#include <string.h>
#include "Eigen/Dense"
#include <math.h>
#include <cstring>
#include <map> 

using namespace Eigen;
using namespace std;

struct Double //makes a type that can store 3 values: x, y, and z coordinates
{
    float x;
    float y;
};

int height = 500;
int width = 500;
//Double coordinate;
//vector<Double> coordinates;
int Sign(int b)
{
	if(b < 0)
	{
		return -1;
	}
	else if(b == 0)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}


//vector<Double> coordinates;
map<int, map<int, int>> coordinates;

void Bresenham(int x1, int y1, int x2, int y2)
{
	map<int, int> coordY;
	int X = x1;
	int Y = y1;
	
	if(coordinates.find(X) != coordinates.end())
	{
		coordY = coordinates[X];
	}
	else
	{
		coordY.clear();
	}
		

	if(x1 == x2)
	{
		if(y1 > y2)
		{
			int T = y1;
			y1 = y2;
			y2 = T;
		}

		for(Y = y1; Y <= y2; Y++)
		{
			
			coordY[Y] = Y;
		}
		
		coordinates[X] = coordY;
		
		return;
	}

	
	int dx = abs(x2-x1);
	int dy = abs(y2-y1);
	int Sx = Sign(x2-x1);
	int Sy = Sign(y2-y1);
	bool interchange;

	//if(dy > dx)
	if(x2<x1)
	{
		int T = dx;
		dx = dy;
		dy = T;
		interchange = true;
	}
	else
	{
		interchange = false;
	}
	
	int E = 2*dy - dx;
	int A = 2*dy;
	int B = 2*dy -2*dx;
	cout << "Line function: E = " << E << " A = " << A << " B = " << B << endl;
	cout << "Line function Dx = " << dx << " Dy = " << dy << " Sx: " << Sx << " Sy: " << Sy << endl;
	//cout << X << ": " << Y << endl;
	//coordinates[X] = Y;
	
	
	
	/*if(coordinates.size() > 1)
	{
		for(int k = 0; k < coordinates.size(); k++)
		{
			if(coordinate.x != coordinates[k].x || coordinate.y != coordinates[k].y)
			{
				coordinates.push_back(coordinate);
			}
		}
	}*/
	coordY[Y] = Y;
	coordinates[X] = coordY;
	cout << "Line function: coordinate = (" << X << ", " << Y << ") " << " E = " << E << " A = " << A << " B = " << B << endl;

	for(int i = 1; i <= dx; i++)
	{
		if(E < 0)
		{
			if(interchange)
			{
				Y = Y + Sy;
			}
			else
			{
				X = X + Sx;
				E = E + A;
			}
		}
		else
		{
			Y = Y + Sy;
			X = X + Sx;
			E = E + B;
		}
		

		//cout << X << ": " << Y << endl;
		//coordinates[X] = Y;
		if(coordinates.find(X) != coordinates.end())
		{
			coordY = coordinates[X];

		}
		else
		{
			coordY.clear();
		}
		
		coordY[Y] = Y;
		
		coordinates[X] = coordY;
		cout << "Line function: coordinate = (" << X << ", " << Y << ") " << "E = " << E << "A = " << A << "B = " << B << endl;
	
		
	}
	
	//lines.push_back(coordinates);
	
	/*for(int k = 0; k < coordinates.size(); k++)
	{
		if(coordinate.x != coordinates[k].x || coordinate.y != coordinates[k].y)
		{
			coordinates.push_back(coordinate);
		}
	}*/

}





int main(int argc,  char **argv)// (number of arguments, array of arguments) First value
//of the array is always the name of the document
{
	/// add in for loops so that it does it for each file given
	/*if (argc <= 1)
	{
		//printf("Error: must input at least one object file path.");
		return 0;
	}

	//projectionMatrix(1, 10, -0.5, 0.5, 0.5, -0.5);
	//finalNDC();
	
	
	for(int k = 1; k < argc; k++)
	{
		cout << k << " " << argv[k] << endl;
		//beginningRead(argv[k]);
		
		Bresenham(0, 0, 5, 5);

	}	
*/

	//Bresenham(50, 30, 50, 50);
	Bresenham(125, 125, 375, 125);
	Bresenham(125, 125, 125, 375);
	Bresenham(125, 375, 375, 375);
	Bresenham(375, 125, 375, 375);
	Bresenham(166, 166, 166, 333);
	Bresenham(333, 166, 333, 333);
	Bresenham(166, 166, 333, 166);
	Bresenham(166, 333, 333, 333);
	Bresenham(125, 125, 166, 166);
	Bresenham(375, 125, 333, 166);
	Bresenham(333, 333, 375, 375);
	Bresenham(125, 375, 166, 333);
	Bresenham(375, 125, 166, 166);
	Bresenham(166, 166, 125, 375);
	Bresenham(375, 375, 333, 166);
	


	

		map<int, int> coordY;
	cout << endl << endl << "printing out coordinates:" << endl;
	map<int,map<int,int>>::iterator it;
	map<int,int>::iterator it2;
	for(it=coordinates.begin(); it!=coordinates.end(); ++it)
	{
		cout << "Coordinate x = " << it->first << "has  the following y numbers: " <<endl;
		coordY = it->second;
		for(it2=coordY.begin(); it2!=coordY.end(); ++it2){
			cout << "y = " << it2->first << endl;
		}
	}

	ofstream outputFile;
	outputFile.open("HELLO.ppm");
	outputFile << "P3 " << endl << width << " " << height << endl << " 255" << endl;
	for(int y = 0; y < height; y++)
	{
		for(int x = 0; x < width; x++)
		{
			
			if(coordinates.find(x) != coordinates.end())
				{
					 
					 coordY = coordinates[x];
					 if(coordY.find(y) != coordY.end())
					 {
					 	//cout << coordinates.at(x) << endl;
						outputFile << "255 255 255" << endl;
						cout << "Drawing coordinate x: " << x << " and y: " << y << endl;
 					 }
 					 else
 					 {
 					 	outputFile << "0 0 0" << endl;
 					 }
					
				}
				else
				{
					outputFile << "0 0 0" << endl;
				}//FOR LINES STUFF!!
		}
	}

	outputFile.close();

}
