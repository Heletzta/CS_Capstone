//Complex Number Class
	
#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include <stdio.h>
#include <string.h>
//#include "Eigen/Dense"
#include <math.h>
//#include <ComplexClass.cpp>

//using namespace Eigen;
using namespace std;

class Complex
{

private:
	double real, imag; 

	//constructors
public:
	Complex(double r, double i)//if you already have a specific real number and imaginary number to put in
	{
		real = r;
		imag = i;
	}


	Complex()//if you don't have the specific numbers yet
	{
		real = imag = 0;
	}

	//Getter and Setter Methods
	double getReal()
	{
		return real;
	}

	double getImag()
	{
		return imag;
	}

	void setReal(double re)
	{
		real = re;
	}

	void setImag(double im)
	{
		imag = im;
	}

	
	//addition + subtraction

	Complex add(Complex k)//add the complex number to another complex number
	{
		Complex Sum;
		Sum.real = real + k.real;
		Sum.imag = imag + k.imag;
		return Sum;
	}

	Complex addNum(double z)//Add the complex number to a real number
	{
		Complex sum;
		sum.real = real + z;
		sum.imag = imag;
		return sum;
	}

	Complex subtract(Complex p)//complex number minus another one
	{
		Complex Diff;
		Diff.real = real - p.real;
		Diff.imag = imag - p.imag;
		return Diff;

	}

	//multiplication + division

	Complex multiply(Complex c)
	{
		Complex product;
		product.real = (real * c.real) - (imag * c.imag);
		product.imag = (real * c.imag) + (c.real * imag);
		return product;
	}

	Complex multiplyNum(double z)
	{
		Complex prod;
		prod.real = real*z;
		prod.imag = imag*z;
		return prod;
	}


	Complex divide(Complex k)
	{
		Complex quotient;
		Complex conj(k.real, -(k.imag));
		quotient.real = ((real * conj.real) - (imag * conj.imag))/((conj.real * k.real) - (conj.imag * k.imag));
		quotient.imag = ((real * conj.imag) + (conj.real * imag))/((conj.real * k.real) - (conj.imag * k.imag));
		return quotient;
	}


	//power of

	Complex power(int pow, Complex c)//complex number to the power of something
	{
		
		for(int k = 0; k < pow-1; k++)
		{
			c = c.multiply(c);
		}
		return c;
	}

	double distance()//the distance of the complex number to 0 (absolute value)- used in the equation
	{
		return sqrt((pow(real, 2) + pow(imag, 2)));
	}


	void print()//print the complex number
	{
		cout << real << " + " << imag << "i" << endl;
	}

};



//***************MAIN********************
	
int main()//tests to see if everything works
{
	double real1,imag1,real2,imag2;

	cout<<"Enter the Real  part of First Number: ";
	cin>>real1;
	cout<<"Enter the imaginary  part of First Number: ";
	cin>>imag1;
	Complex obj1(real1,imag1);
	obj1.print();

	cout<<"Enter the Real part of Second Number: ";
	cin>>real2;
	cout<<"Enter the Imaginary part of second number: ";
	cin>>imag2;
	Complex obj2(real2,imag2);
	obj2.print();

	Complex c;
	c = obj1.add(obj2);
	cout<<"Addition is : ("<<c.getReal()<<")+("<<c.getImag()<<")i"<<endl;
	c= obj1.subtract(obj2);
	cout<<endl<<"Subtraction is : ("<<c.getReal()<<")+("<<c.getImag()<<")i"<<endl;

	c= obj1.multiply(obj2);
	cout<<endl<<"Multiplication is : ("<<c.getReal()<<")+("<<c.getImag()<<")i"<<endl;

	c= obj1.divide(obj2);
	cout<<endl<<"Division result  is : ("<<c.getReal()<<")+("<<c.getImag()<<")i"<<endl;
	c= obj1.power(5, obj1);
	cout<<endl<<"5th Power result is: ("<<c.getReal()<<")+("<<c.getImag()<<")i"<<endl;
	cout<< "The distance of the first number to 0 is " << obj1.distance() << " and the distance of the second number to 0 is " << obj2.distance() << endl;

	return 0;
}




