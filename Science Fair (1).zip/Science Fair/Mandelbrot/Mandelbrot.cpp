// Mandelbrot Code
#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include <stdio.h>
#include <string.h>
//#include "Eigen/Dense"
#include <math.h>

//using namespace Eigen;
using namespace std;



struct Triple //makes a type that can store 3 values: x, y, and z coordinates
{
    float x;
    float y;
    float z;
};

struct Double //makes a type that can store 3 values: x, y, and z coordinates
{
    float x;
    float y;

};


int main(int argc,  char **argv)// (number of arguments, array of arguments) First value
//of the array is always the name of the document
{
	//the c number is the point we will plot. it is a complex number written as "a + bi". the a is the x axis, bi is the y axis
	int x = 0;
	int y = 0;
	int a = 0;
	int b = 0;
	int z = 0;
	int i;
	pow(i, 2) = -1 // this probably won't work
	double c = 0;
	vector<Triple> colors;
	Triple color;
	Double coordinate;
	vector<Double> coordinates;
	int escapeTime = 0; // how many iterations before it escapes to infinity
	cout << "P3"  << endl << "1000 1000" << endl << "255" << endl;
	
	for(int a = -1000; a < 1000; a++) // iterate through multiple complex numbers c
	{
		for(int b = -1000; b < 1000; b++)
		{
			c = a + b*i;
			ESCAPE: while(pow(z, 2) + c < 2) //this iterates with z = 0 and a specific c number
			{
				escapeTime++;
				z = pow(z, 2) + c
				if(escapeTime > 256) //if it converges, color it black, store the color and the coordinate in arrays
				{
					x = a;
					y = b*i;
					color = 0, 0, 0; // this might be written differently, same with the double
					colors.push_back(color);
					coordinate = x, y;
					coordinates.push_back(coordinate);
					break ESCAPE;
				}//stop while loop

			}
			if(escapeTime <= 256 && > 150) // if it takes a while to diverge, color it white
			{
				x = a;
				y = b*i;
				color = 255, 255, 255;
				colors.push_back(color);
				coordinate = x, y;
				coordinates.push_back(coordinate);
				
			}
			else if(escapeTime <= 150)// if it diverges soon, color it blue
			{
				x = a;
				y = b*i;
				color = 0, 255, 0;
				colors.push_back(color);
				coordinate = x, y;
				coordinates.push_back(coordinate);
			}
		}
	}
		
	//this is where I print it all out - another issue is that it has to be in order of the points - PPM image info
	//for(int d = 0; d < coordinates.size(); d++)
	//{
		for(int k = 0; k < colors.size(); k++)
		{
			cout << colors[k].x << " " << colors[k].y << " " << colors[k].z;
		}
	//}

	


}