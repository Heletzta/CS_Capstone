//Mandelbrot code 2.0 - implements Complex class and fixes other bugs

// Mandelbrot Code
#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include <stdio.h>
#include <string.h>
//#include "Eigen/Dense"
#include <math.h>
//#include <ComplexClass.cpp>

//using namespace Eigen;
using namespace std;

class Complex
{

private:
	double real, imag; 

	//constructors
public:
	Complex(double r, double i)
	{
		real = r;
		imag = i;
	}


	Complex()
	{
		real = imag = 0;
	}

	double getReal()
	{
		return real;
	}

	double getImag()
	{
		return imag;
	}

	void setReal(double re)
	{
		real = re;
	}

	void setImag(double im)
	{
		imag = im;
	}

	
	//addition + subtraction

	Complex add(Complex k)
	{
		Complex Sum;
		Sum.real = real + k.real;
		Sum.imag = imag + k.imag;
		return Sum;
	}

	Complex addNum(double z)
	{
		Complex sum;
		sum.real = real + z;
		sum.imag = imag;
		return sum;
	}

	Complex subtract(Complex p)
	{
		Complex Diff;
		Diff.real = real - p.real;
		Diff.imag = imag - p.imag;
		return Diff;

	}

	//multiplication + division(don't really need division)

	Complex multiply(Complex c)
	{
		Complex product;
		product.real = (real * c.real) - (imag * c.imag);
		product.imag = (real * c.imag) + (c.real * imag);
		return product;
	}

	Complex multiplyNum(double z)
	{
		Complex prod;
		prod.real = real*z;
		prod.imag = imag*z;
		return prod;
	}


	Complex divide(Complex k)
	{
		Complex quotient;
		Complex conj(k.real, -(k.imag));
		quotient.real = ((real * conj.real) - (imag * conj.imag))/((conj.real * k.real) - (conj.imag * k.imag));
		quotient.imag = ((real * conj.imag) + (conj.real * imag))/((conj.real * k.real) - (conj.imag * k.imag));
		return quotient;
	}


	//power of

	Complex power(int pow, Complex c)
	{
		
		for(int k = 0; k < pow-1; k++)
		{
			c = c.multiply(c);
		}
		return c;
	}

	double distance()
	{
		return sqrt((pow(real, 2) + pow(imag, 2)));
	}


	void print()
	{
		cout << real << " + " << imag << "i" << endl;
	}


};

//*************************************************************MAIN***********************************************************


struct Triple //makes a type that can store 3 values: x, y, and z coordinates
{
    int r;
    int g;
    int b;
};

struct Double //makes a type that can store 3 values: x, y, and z coordinates
{
    float x;
    float y;

};


int main(int argc,  char **argv)// (number of arguments, array of arguments) First value
//of the array is always the name of the document
{
	int xOffset = 250;
	int yOffset = 250;
	int x = 0;
	int y = 0;
	double a = 0;
	double b = 0;
	Complex z(0, 0);
	Complex c(0, 0);
	Triple color;
	Double coordinate;
	Triple grid[500][500];//THE MAXIMUM IT WILL TAKE IS 835 BY 835 OR IT GIVES A CORE DUMP ERROR
	int escapeTime = 0; // how many iterations before it escapes to infinity
	int num = 0;
	
	for(a = -25; a < 25; a += 0.1) // iterate through multiple complex numbers c
	{
		for(b = -25; b < 25; b += 0.1)
		{
			
			num++;
			z.setReal(0);
			z.setImag(0);
			escapeTime = 0;
			c.setReal(a);
			c.setImag(b);
			color.r = 0;
			color.g = 0;
			color.b = 0;
			//cout << "Sequence starts with this complex number: ";
			//c.print();
			while(z.distance() < 2) //this iterates with z = 0 and a specific c number
			{
				//cout << c.add(z.power(2, z)).distance() << endl;
				escapeTime++;
				z = c.add(z.power(2, z));
				//z.print();
				cout << endl;
				if(escapeTime > 100) //if it converges, color it black, store the color and the coordinate in arrays
				{
					x = (int)(c.getReal() + xOffset);
					y = (int)(c.getImag() + yOffset);
					color.r = 0;
					color.g = 0;
					color.b = 0;

					//cout << "X = " << x << " and Y = " << y << endl;
					grid[y][x] = color;
					//cout << grid[y][x].r << " " << grid[y][x].g << grid[y][x].b;
					break;
				}//stop while loop

			}
			if(escapeTime <= 100 && escapeTime > 50) // if it takes a while to diverge, color it white
			{
				x = (int)(c.getReal() + xOffset);
				y = (int)(c.getImag() + yOffset);
				color.r = 255;
				color.g = 255;
				color.b = 255;
				//cout << "X = " << x << " and Y = " << y << endl;
				grid[y][x] = color;
				
				
			}
			else if(escapeTime <= 50)// if it diverges soon, color it blue
			{
				x = (int)(c.getReal() + xOffset);
				y = (int)(c.getImag() + yOffset);
				color.r = 0;
				color.g = 0;
				color.b = 255;
				//cout << "X = " << x << " and Y = " << y << endl;
				grid[y][x] = color;

			}
		}
	}
		
	//this is where I print it all out - another issue is that it has to be in order of the points - PPM image info
	ofstream outputFile;
	outputFile.open("Mandelbrot.ppm");
	outputFile << "P3"  << endl << "500 500" << endl << "255" << endl;
	//IN THE GRID, SINCE IT'S A DOUBLE ARRAY, 
	//GRID --> [ROW][COLUMN] WHICH IS [Y][X]
	for(int y = 0; y < 500; y++)
	{
		for(int x = 0; x < 500; x++)
		{
			
			outputFile << grid[y][x].r << " " << grid[y][x].g << " " << grid[y][x].b << endl;
			cout << grid[y][x].r << " " << grid[y][x].g << " " << grid[y][x].b << endl;
			
			
		}
		
	}

	outputFile.close();
	cout << num;
}

	


